import os
import zipfile
import shutil

ROOT_DIR = r"L:\car-dealership"
OUTPUT_ZIP = os.path.join(ROOT_DIR, "submission", "aurelia-motors-submission.zip")

EXCLUDE_DIRS = {
    "node_modules",
    ".git",
    "dist",
    ".turbo",
    ".cache",
    ".system_generated",
    "data",
}

EXCLUDE_EXTENSIONS = {
    ".pyc",
    ".log",
}

EXCLUDE_FILES = {
    ".env",
    "aurelia-motors-submission.zip",
}

print(f"Packaging repository from: {ROOT_DIR}")
print(f"Target archive: {OUTPUT_ZIP}")

if os.path.exists(OUTPUT_ZIP):
    os.remove(OUTPUT_ZIP)

file_count = 0
with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
    for root, dirs, files in os.walk(ROOT_DIR):
        # Exclude directories in place
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith(".git")]
        
        for file in files:
            if file in EXCLUDE_FILES:
                continue
            ext = os.path.splitext(file)[1].lower()
            if ext in EXCLUDE_EXTENSIONS:
                continue
            
            full_path = os.path.join(root, file)
            # Avoid packing the zip into itself
            if os.path.abspath(full_path) == os.path.abspath(OUTPUT_ZIP):
                continue
                
            rel_path = os.path.relpath(full_path, ROOT_DIR)
            
            # Additional safety checks
            path_parts = rel_path.replace("\\", "/").split("/")
            if any(part in EXCLUDE_DIRS for part in path_parts):
                continue
            if ".env" in path_parts and not any("example" in part.lower() for part in path_parts):
                continue

            zipf.write(full_path, arcname=rel_path)
            file_count += 1

zip_size_bytes = os.path.getsize(OUTPUT_ZIP)
zip_size_mb = zip_size_bytes / (1024 * 1024)

print(f"Packaged {file_count} files.")
print(f"Archive size: {zip_size_bytes} bytes ({zip_size_mb:.2f} MB)")
if zip_size_mb <= 25.0:
    print("SUCCESS: Archive size is well within the 25 MB limit!")
else:
    print("WARNING: Archive size exceeds 25 MB limit!")
